from pyswmap.mapalgs import (
        MapCalc,
        DmrCalc,
)
